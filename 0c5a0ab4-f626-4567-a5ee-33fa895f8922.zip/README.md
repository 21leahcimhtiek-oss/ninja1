# 🔐 Proximity-Locked AES-256 Encryption

**Your phone is the key. No phone nearby = no access.**

A complete 256-bit encryption toolkit that uses your phone as a proximity key — like a keycard for your data. Supports three proximity detection modes: Bluetooth, WiFi network presence, and local web server check-in.

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    AES-256-GCM Core                         │
│         (encryption/aes256.py — works standalone)           │
├─────────────┬─────────────────┬─────────────────────────────┤
│  Bluetooth  │   WiFi Network  │   Web Server Check-In       │
│  Proximity  │   Presence      │   (Phone opens a page)      │
│             │                 │                             │
│  Uses BLE   │  Ping + ARP     │  HTTP server + heartbeat    │
│  scanning   │  MAC verify     │  session management         │
├─────────────┴─────────────────┴─────────────────────────────┤
│              Unified CLI  (proximity_cli.py)                │
└─────────────────────────────────────────────────────────────┘
```

### How Key Splitting Works

Your 256-bit encryption key is **split in two** using XOR:

```
full_key = local_component ⊕ device_component

local_component  → stored on your computer (config file)
device_component → derived from your phone's identity
                   (BT address / MAC address / device fingerprint)
```

To reconstruct the key, **both halves are needed**. Without your phone nearby, the key literally cannot be reassembled.

---

## 📁 File Structure

```
/workspace
├── encryption/
│   ├── __init__.py
│   ├── aes256.py                  # Core AES-256-GCM module
│   ├── proximity_bluetooth.py     # Mode 1: Bluetooth proximity
│   ├── proximity_wifi.py          # Mode 2: WiFi network presence
│   ├── proximity_webserver.py     # Mode 3: Web server check-in
│   └── web_ui/
│       ├── style.css              # Phone check-in UI styles
│       └── index.html             # Phone check-in UI page
├── encrypt_cli.py                 # Standalone encryption CLI
├── proximity_cli.py               # Unified proximity CLI
├── demo.py                        # Full test suite
└── README.md                      # This file
```

---

## 🚀 Quick Start

### Prerequisites

```bash
pip install cryptography        # Required — core crypto backend
pip install bleak               # Optional — for Bluetooth mode only
```

### 1. Standalone Encryption (No proximity)

```bash
# Generate a 256-bit key
python encrypt_cli.py generate-key

# Encrypt text
python encrypt_cli.py encrypt --text "top secret" --key <YOUR_HEX_KEY>

# Decrypt text
python encrypt_cli.py decrypt --text "<CIPHERTEXT>" --key <YOUR_HEX_KEY>

# Password-based (no key needed)
python encrypt_cli.py encrypt --text "secret" --password "MyP@ssw0rd"
python encrypt_cli.py decrypt --text "<TOKEN>" --password "MyP@ssw0rd"

# File encryption
python encrypt_cli.py encrypt-file --input secret.pdf --output secret.enc --key <KEY>
python encrypt_cli.py decrypt-file --input secret.enc --output secret.pdf --key <KEY>
```

---

## 📱 Mode 1: Bluetooth Proximity

Your phone's Bluetooth signal acts as a proximity key. Data unlocks only when your phone is within Bluetooth range (~10-30 feet).

### Setup

```bash
# Make sure your phone's Bluetooth is ON and discoverable
pip install bleak

# Pair with your phone
python proximity_cli.py bluetooth pair
```

The tool will scan for nearby Bluetooth devices, show a list, and you select your phone. A 256-bit key is generated and split between your computer and your phone's BT identity.

### Usage

```bash
# Check if phone is nearby
python proximity_cli.py bluetooth status

# Encrypt (phone must be nearby)
python proximity_cli.py bluetooth encrypt --text "classified data"

# Decrypt (phone must be nearby)
python proximity_cli.py bluetooth decrypt --text "<CIPHERTEXT>"

# File operations
python proximity_cli.py bluetooth encrypt-file --input doc.pdf --output doc.enc
python proximity_cli.py bluetooth decrypt-file --input doc.enc --output doc.pdf
```

### How It Works

1. **Scan**: Uses Bluetooth Low Energy (BLE) to scan for your phone
2. **Verify**: Checks that your phone's BT address matches the paired device
3. **Signal Check**: Optionally enforces minimum signal strength (RSSI threshold)
4. **Key Reconstruct**: XORs the local component with your phone's BT-derived component
5. **Encrypt/Decrypt**: Proceeds only if key reconstruction succeeds

---

## 📶 Mode 2: WiFi Network Presence

Your phone must be connected to the same WiFi network. The tool detects your phone by pinging its IP and verifying its MAC address.

### Setup

```bash
# Make sure your phone is on the same WiFi as your computer
python proximity_cli.py wifi pair
```

Options:
- **Scan network**: Automatically finds all devices on your WiFi
- **Manual entry**: Enter your phone's IP address directly

### Finding Your Phone's IP

- **iPhone**: Settings → WiFi → tap (i) next to your network
- **Android**: Settings → WiFi → tap your network → IP address

### Usage

```bash
# Check if phone is on network
python proximity_cli.py wifi status

# Encrypt (phone must be on same WiFi)
python proximity_cli.py wifi encrypt --text "classified data"

# Decrypt
python proximity_cli.py wifi decrypt --text "<CIPHERTEXT>"

# Files
python proximity_cli.py wifi encrypt-file --input doc.pdf --output doc.enc
python proximity_cli.py wifi decrypt-file --input doc.enc --output doc.pdf
```

### How It Works

1. **Ping**: Sends ICMP ping to your phone's IP
2. **ARP Verify**: Checks the ARP table to confirm the MAC address matches
3. **Anti-Spoof**: If the IP responds but MAC doesn't match → access denied
4. **Key Reconstruct**: Uses your phone's MAC address to derive the device component

---

## 🌐 Mode 3: Web Server Check-In

A local web server runs on your computer. You open the URL on your phone and tap "Check In." As long as the page is open, encryption is unlocked.

### Setup & Usage

```bash
# Start the server
python proximity_cli.py web server --port 7777
```

The server displays a URL like `http://192.168.1.100:7777`. Open it on your phone:

1. 📱 Open the URL in your phone's browser
2. 🔓 Tap **"Check In"** — encryption unlocks
3. 💚 Keep the page open — heartbeats maintain the session
4. 🔒 Close the page or tap **"Check Out"** — encryption locks

In a **separate terminal**, run encrypt/decrypt commands:

```bash
# Encrypt while phone is checked in
python proximity_cli.py web encrypt --text "classified data"

# Decrypt
python proximity_cli.py web decrypt --text "<CIPHERTEXT>"

# Check status
python proximity_cli.py web status
```

### How It Works

1. **Server**: HTTP server on your LAN, serves a check-in page
2. **Session**: Phone check-in creates a session with a crypto token
3. **Heartbeat**: Phone sends a ping every 5 seconds to keep the session alive
4. **Timeout**: If heartbeats stop for >15 seconds, session expires and encryption locks
5. **Auto Check-Out**: Closing the browser page automatically checks out (via `beforeunload`)
6. **Key Splitting**: Device fingerprint (derived from browser properties) is used for key derivation

### Web UI Features

- Real-time connection status with animated indicators
- Session info (ID, check-in time, heartbeat status)
- Automatic reconnection handling
- Dark theme, mobile-optimized design
- Works on any phone browser (iOS Safari, Android Chrome, etc.)

---

## 🔒 Security Details

| Feature | Specification |
|---|---|
| **Algorithm** | AES-256-GCM (authenticated encryption) |
| **Key Size** | 256 bits (32 bytes) |
| **Mode** | GCM (Galois/Counter Mode) — integrity + confidentiality |
| **Key Derivation** | PBKDF2-HMAC-SHA256 (600,000 iterations) |
| **Salt** | 128-bit random per operation |
| **Nonce/IV** | 96-bit random per encryption |
| **Auth Tag** | 128-bit GCM tag |
| **Key Splitting** | XOR-based split (local ⊕ device) |
| **Tamper Detection** | GCM tag verification rejects modified ciphertext |
| **Wrong Key** | Automatically detected and rejected |

### Security Considerations

- **Bluetooth mode** is the most secure proximity option (requires physical nearness)
- **WiFi mode** is convenient but IP addresses can change; MAC verification adds security
- **Web mode** is the easiest to set up but relies on the phone keeping a browser tab open
- Config files are stored with `600` permissions (owner-read/write only)
- Keys are never stored in plaintext — only the local XOR component is saved
- Each encryption produces unique ciphertext (random nonce per operation)

---

## 🧪 Running Tests

```bash
# Full test suite — tests all encryption features
python demo.py

# Check system info
python encrypt_cli.py info
```

---

## 💡 Tips

- **Bluetooth**: Best for high-security scenarios. Phone must have BLE enabled.
- **WiFi**: Best for convenience. Assign a static IP to your phone for reliability.
- **Web Server**: Best for quick setup. No special phone configuration needed — just open a URL.
- **Combine modes**: You can use different modes for different data. Each has its own config.
- **Backup**: Save your initial key output from the `pair` command. If you lose your config, you'll need it.

---

## 🖥️ Platform Support

| Platform | Bluetooth | WiFi | Web Server |
|---|---|---|---|
| Linux | ✅ (with `bleak`) | ✅ | ✅ |
| macOS | ✅ (with `bleak`) | ✅ | ✅ |
| Windows | ✅ (with `bleak`) | ✅ | ✅ |

### Phone Compatibility

- Any phone with Bluetooth 4.0+ (BLE) for Bluetooth mode
- Any phone on the same WiFi for WiFi mode
- Any phone with a web browser for Web Server mode

---

## 📜 License

MIT License — use freely for personal and commercial projects.