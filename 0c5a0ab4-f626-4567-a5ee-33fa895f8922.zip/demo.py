#!/usr/bin/env python3
"""
AES-256 Encryption — Full Demonstration & Test Suite
=====================================================
This script demonstrates every feature of the encryption module
and verifies correctness with assertions.
"""

import os
import sys

# Ensure the workspace is on the path
sys.path.insert(0, os.path.dirname(__file__))

from encryption.aes256 import (
    generate_key,
    key_to_hex,
    key_from_hex,
    key_to_base64,
    key_from_base64,
    derive_key_from_password,
    encrypt,
    decrypt,
    encrypt_to_base64,
    decrypt_from_base64,
    encrypt_with_password,
    decrypt_with_password,
    encrypt_file,
    decrypt_file,
    encrypt_file_with_password,
    decrypt_file_with_password,
    get_info,
)

SEPARATOR = "=" * 64


def section(title):
    print(f"\n{SEPARATOR}")
    print(f"  {title}")
    print(SEPARATOR)


def main():
    print(SEPARATOR)
    print("       AES-256-GCM ENCRYPTION — FULL DEMO & TESTS")
    print(SEPARATOR)

    # ------------------------------------------------------------------
    section("1. System Info")
    info = get_info()
    for k, v in info.items():
        label = k.replace("_", " ").title()
        print(f"   {label:.<35} {v}")

    # ------------------------------------------------------------------
    section("2. Key Generation")
    key = generate_key()
    hex_key = key_to_hex(key)
    b64_key = key_to_base64(key)
    print(f"   Random 256-bit key (hex) : {hex_key}")
    print(f"   Random 256-bit key (b64) : {b64_key}")
    print(f"   Key length               : {len(key)} bytes = {len(key)*8} bits")

    # Verify round-trip
    assert key_from_hex(hex_key) == key, "Hex round-trip failed"
    assert key_from_base64(b64_key) == key, "Base64 round-trip failed"
    print("   ✅ Key serialization round-trip passed")

    # ------------------------------------------------------------------
    section("3. Password-Based Key Derivation (PBKDF2)")
    password = "SuperSecret!2024"
    derived_key, salt = derive_key_from_password(password)
    print(f"   Password        : {password}")
    print(f"   Salt (hex)      : {salt.hex()}")
    print(f"   Derived key     : {derived_key.hex()}")
    print(f"   Key size        : {len(derived_key)*8} bits")

    # Same password + salt → same key
    derived_key2, _ = derive_key_from_password(password, salt)
    assert derived_key == derived_key2, "Deterministic derivation failed"
    print("   ✅ Deterministic key derivation verified")

    # Different salt → different key
    derived_key3, salt3 = derive_key_from_password(password)
    assert derived_key3 != derived_key, "Different salts should yield different keys"
    print("   ✅ Different salts produce different keys")

    # ------------------------------------------------------------------
    section("4. Encrypt / Decrypt (Raw Bytes)")
    message = b"This is a top-secret message. Handle with care!"
    encrypted = encrypt(message, key)
    print(f"   Plaintext       : {message.decode()}")
    print(f"   Encrypted size  : {len(encrypted)} bytes")
    print(f"   Encrypted (hex) : {encrypted[:40].hex()}...")

    decrypted = decrypt(encrypted, key)
    assert decrypted == message, "Decryption mismatch"
    print(f"   Decrypted       : {decrypted.decode()}")
    print("   ✅ Raw bytes encrypt/decrypt passed")

    # Verify different encryptions produce different ciphertext (random nonce)
    encrypted2 = encrypt(message, key)
    assert encrypted != encrypted2, "Two encryptions should differ (unique nonce)"
    decrypted2 = decrypt(encrypted2, key)
    assert decrypted2 == message, "Second decryption failed"
    print("   ✅ Unique nonce per encryption verified")

    # ------------------------------------------------------------------
    section("5. Encrypt / Decrypt (Base64 Strings)")
    secret_text = "The quick brown fox jumps over the lazy dog 🦊🐶"
    b64_cipher = encrypt_to_base64(secret_text, key)
    print(f"   Plaintext  : {secret_text}")
    print(f"   Ciphertext : {b64_cipher[:60]}...")

    recovered = decrypt_from_base64(b64_cipher, key)
    assert recovered == secret_text, "Base64 string decryption failed"
    print(f"   Recovered  : {recovered}")
    print("   ✅ Base64 string encrypt/decrypt passed")

    # ------------------------------------------------------------------
    section("6. Password-Based Encrypt / Decrypt")
    pwd = "MyStrongP@ssw0rd!"
    secret = "Classified information: Project Aurora is a go."
    token = encrypt_with_password(secret, pwd)
    print(f"   Password   : {pwd}")
    print(f"   Plaintext  : {secret}")
    print(f"   Token      : {token[:60]}...")

    recovered_pwd = decrypt_with_password(token, pwd)
    assert recovered_pwd == secret, "Password-based decryption failed"
    print(f"   Recovered  : {recovered_pwd}")
    print("   ✅ Password-based encrypt/decrypt passed")

    # Wrong password should fail
    try:
        decrypt_with_password(token, "WrongPassword")
        print("   ❌ Should have failed with wrong password!")
        sys.exit(1)
    except Exception:
        print("   ✅ Wrong password correctly rejected")

    # ------------------------------------------------------------------
    section("7. File Encryption (Key-Based)")
    test_content = "This file contains sensitive financial data.\nAccount: 1234-5678\nBalance: $1,000,000"

    # Write test file
    with open("test_secret.txt", "w") as f:
        f.write(test_content)
    print(f"   Created test file: test_secret.txt ({len(test_content)} bytes)")

    # Encrypt file
    encrypt_file("test_secret.txt", "test_secret.enc", key)
    enc_size = os.path.getsize("test_secret.enc")
    print(f"   Encrypted file : test_secret.enc ({enc_size} bytes)")

    # Decrypt file
    decrypt_file("test_secret.enc", "test_secret_recovered.txt", key)
    with open("test_secret_recovered.txt", "r") as f:
        recovered_content = f.read()

    assert recovered_content == test_content, "File decryption content mismatch"
    print(f"   Decrypted file : test_secret_recovered.txt")
    print("   ✅ File encryption/decryption passed")

    # ------------------------------------------------------------------
    section("8. File Encryption (Password-Based)")
    encrypt_file_with_password("test_secret.txt", "test_secret_pwd.enc", pwd)
    enc_size2 = os.path.getsize("test_secret_pwd.enc")
    print(f"   Encrypted file : test_secret_pwd.enc ({enc_size2} bytes)")

    decrypt_file_with_password("test_secret_pwd.enc", "test_secret_pwd_recovered.txt", pwd)
    with open("test_secret_pwd_recovered.txt", "r") as f:
        recovered_pwd_content = f.read()

    assert recovered_pwd_content == test_content, "Password file decryption mismatch"
    print(f"   Decrypted file : test_secret_pwd_recovered.txt")
    print("   ✅ Password-based file encryption/decryption passed")

    # ------------------------------------------------------------------
    section("9. Tamper Detection Test")
    encrypted_data = encrypt(b"Integrity test data", key)
    # Flip a byte in the ciphertext
    tampered = bytearray(encrypted_data)
    tampered[-20] ^= 0xFF  # Flip bits in the ciphertext area
    try:
        decrypt(bytes(tampered), key)
        print("   ❌ Should have detected tampering!")
        sys.exit(1)
    except Exception:
        print("   ✅ Tampered data correctly detected and rejected")

    # ------------------------------------------------------------------
    section("10. Wrong Key Detection Test")
    wrong_key = generate_key()
    try:
        decrypt(encrypted_data, wrong_key)
        print("   ❌ Should have failed with wrong key!")
        sys.exit(1)
    except Exception:
        print("   ✅ Wrong key correctly rejected")

    # ------------------------------------------------------------------
    # Cleanup
    for f in ["test_secret.txt", "test_secret.enc", "test_secret_recovered.txt",
              "test_secret_pwd.enc", "test_secret_pwd_recovered.txt"]:
        if os.path.exists(f):
            os.remove(f)

    section("ALL TESTS PASSED ✅")
    print(f"   Your AES-256-GCM encryption toolkit is ready to use!")
    print(f"\n   Quick start:")
    print(f"     python encrypt_cli.py generate-key")
    print(f"     python encrypt_cli.py encrypt --text 'secret' --key <KEY>")
    print(f"     python encrypt_cli.py decrypt --text '<CIPHER>' --key <KEY>")
    print(f"     python encrypt_cli.py info")
    print(f"\n{SEPARATOR}\n")


if __name__ == "__main__":
    main()