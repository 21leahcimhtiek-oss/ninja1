#!/usr/bin/env python3
"""
AES-256 Encryption CLI
======================
Command-line interface for encrypting and decrypting text and files
using AES-256-GCM authenticated encryption.

Usage:
    python encrypt_cli.py generate-key
    python encrypt_cli.py encrypt --text "secret message" --key <hex_key>
    python encrypt_cli.py decrypt --text "<ciphertext>" --key <hex_key>
    python encrypt_cli.py encrypt --text "secret message" --password "mypassword"
    python encrypt_cli.py decrypt --text "<token>" --password "mypassword"
    python encrypt_cli.py encrypt-file --input file.txt --output file.enc --key <hex_key>
    python encrypt_cli.py decrypt-file --input file.enc --output file.txt --key <hex_key>
    python encrypt_cli.py encrypt-file --input file.txt --output file.enc --password "mypass"
    python encrypt_cli.py decrypt-file --input file.enc --output file.txt --password "mypass"
    python encrypt_cli.py info
"""

import argparse
import sys
import getpass

from encryption.aes256 import (
    generate_key,
    key_to_hex,
    key_from_hex,
    key_to_base64,
    encrypt_to_base64,
    decrypt_from_base64,
    encrypt_with_password,
    decrypt_with_password,
    encrypt_file,
    decrypt_file,
    encrypt_file_with_password,
    decrypt_file_with_password,
    get_info,
)


def cmd_generate_key(args):
    """Generate a new 256-bit key."""
    key = generate_key()
    hex_key = key_to_hex(key)
    b64_key = key_to_base64(key)

    print("=" * 60)
    print("  AES-256 Key Generated Successfully")
    print("=" * 60)
    print(f"\n  Hex format:    {hex_key}")
    print(f"  Base64 format: {b64_key}")
    print(f"  Key size:      256 bits (32 bytes)")
    print("\n  ⚠️  Store this key securely! Anyone with this key")
    print("     can decrypt your data.")
    print("=" * 60)


def cmd_encrypt_text(args):
    """Encrypt a text message."""
    text = args.text
    if not text:
        text = input("Enter text to encrypt: ")

    if args.password:
        password = args.password
        if password == "-":
            password = getpass.getpass("Enter password: ")
        result = encrypt_with_password(text, password)
        print("\n🔒 Encrypted (password-based):\n")
        print(result)
    elif args.key:
        key = key_from_hex(args.key)
        result = encrypt_to_base64(text, key)
        print("\n🔒 Encrypted:\n")
        print(result)
    else:
        print("Error: Provide either --key or --password", file=sys.stderr)
        sys.exit(1)


def cmd_decrypt_text(args):
    """Decrypt a text message."""
    text = args.text
    if not text:
        text = input("Enter ciphertext to decrypt: ")

    try:
        if args.password:
            password = args.password
            if password == "-":
                password = getpass.getpass("Enter password: ")
            result = decrypt_with_password(text, password)
        elif args.key:
            key = key_from_hex(args.key)
            result = decrypt_from_base64(text, key)
        else:
            print("Error: Provide either --key or --password", file=sys.stderr)
            sys.exit(1)

        print("\n🔓 Decrypted:\n")
        print(result)

    except Exception as e:
        print(f"\n❌ Decryption failed: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_encrypt_file(args):
    """Encrypt a file."""
    if not args.input or not args.output:
        print("Error: --input and --output are required", file=sys.stderr)
        sys.exit(1)

    try:
        if args.password:
            password = args.password
            if password == "-":
                password = getpass.getpass("Enter password: ")
            encrypt_file_with_password(args.input, args.output, password)
        elif args.key:
            key = key_from_hex(args.key)
            encrypt_file(args.input, args.output, key)
        else:
            print("Error: Provide either --key or --password", file=sys.stderr)
            sys.exit(1)

        print(f"\n🔒 File encrypted successfully!")
        print(f"   Input:  {args.input}")
        print(f"   Output: {args.output}")

    except FileNotFoundError:
        print(f"\n❌ File not found: {args.input}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Encryption failed: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_decrypt_file(args):
    """Decrypt a file."""
    if not args.input or not args.output:
        print("Error: --input and --output are required", file=sys.stderr)
        sys.exit(1)

    try:
        if args.password:
            password = args.password
            if password == "-":
                password = getpass.getpass("Enter password: ")
            decrypt_file_with_password(args.input, args.output, password)
        elif args.key:
            key = key_from_hex(args.key)
            decrypt_file(args.input, args.output, key)
        else:
            print("Error: Provide either --key or --password", file=sys.stderr)
            sys.exit(1)

        print(f"\n🔓 File decrypted successfully!")
        print(f"   Input:  {args.input}")
        print(f"   Output: {args.output}")

    except FileNotFoundError:
        print(f"\n❌ File not found: {args.input}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Decryption failed: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_info(args):
    """Display encryption configuration info."""
    info = get_info()
    print("=" * 60)
    print("  AES-256 Encryption Configuration")
    print("=" * 60)
    for k, v in info.items():
        label = k.replace("_", " ").title()
        print(f"  {label:.<30} {v}")
    print("=" * 60)


def main():
    parser = argparse.ArgumentParser(
        description="AES-256-GCM Encryption Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Generate a key:
    python encrypt_cli.py generate-key

  Encrypt text with key:
    python encrypt_cli.py encrypt --text "Hello World" --key <hex_key>

  Decrypt text with key:
    python encrypt_cli.py decrypt --text "<ciphertext>" --key <hex_key>

  Encrypt text with password:
    python encrypt_cli.py encrypt --text "Hello World" --password "mysecret"

  Decrypt text with password:
    python encrypt_cli.py decrypt --text "<token>" --password "mysecret"

  Encrypt a file:
    python encrypt_cli.py encrypt-file --input secret.txt --output secret.enc --key <hex_key>

  Decrypt a file:
    python encrypt_cli.py decrypt-file --input secret.enc --output secret.txt --key <hex_key>

  Show config info:
    python encrypt_cli.py info
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # generate-key
    subparsers.add_parser("generate-key", help="Generate a new 256-bit encryption key")

    # encrypt
    enc_parser = subparsers.add_parser("encrypt", help="Encrypt text")
    enc_parser.add_argument("--text", "-t", help="Text to encrypt")
    enc_parser.add_argument("--key", "-k", help="Encryption key (hex)")
    enc_parser.add_argument("--password", "-p", help="Password (use '-' for prompt)")

    # decrypt
    dec_parser = subparsers.add_parser("decrypt", help="Decrypt text")
    dec_parser.add_argument("--text", "-t", help="Ciphertext to decrypt")
    dec_parser.add_argument("--key", "-k", help="Decryption key (hex)")
    dec_parser.add_argument("--password", "-p", help="Password (use '-' for prompt)")

    # encrypt-file
    enc_file_parser = subparsers.add_parser("encrypt-file", help="Encrypt a file")
    enc_file_parser.add_argument("--input", "-i", help="Input file path")
    enc_file_parser.add_argument("--output", "-o", help="Output file path")
    enc_file_parser.add_argument("--key", "-k", help="Encryption key (hex)")
    enc_file_parser.add_argument("--password", "-p", help="Password (use '-' for prompt)")

    # decrypt-file
    dec_file_parser = subparsers.add_parser("decrypt-file", help="Decrypt a file")
    dec_file_parser.add_argument("--input", "-i", help="Input file path")
    dec_file_parser.add_argument("--output", "-o", help="Output file path")
    dec_file_parser.add_argument("--key", "-k", help="Decryption key (hex)")
    dec_file_parser.add_argument("--password", "-p", help="Password (use '-' for prompt)")

    # info
    subparsers.add_parser("info", help="Show encryption configuration")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    commands = {
        "generate-key": cmd_generate_key,
        "encrypt": cmd_encrypt_text,
        "decrypt": cmd_decrypt_text,
        "encrypt-file": cmd_encrypt_file,
        "decrypt-file": cmd_decrypt_file,
        "info": cmd_info,
    }

    commands[args.command](args)


if __name__ == "__main__":
    main()