#!/usr/bin/env python3
"""
Proximity Encryption CLI — Unified Launcher
=============================================
Supports all 3 proximity modes:
  1. bluetooth  — Phone Bluetooth as proximity key
  2. wifi       — Phone on same WiFi network as key
  3. web        — Phone checks in via local web server

Usage:
  python proximity_cli.py <mode> <command> [options]

Modes:
  bluetooth    Bluetooth Low Energy proximity
  wifi         WiFi / LAN network presence
  web          Local web server check-in

Commands:
  pair               Pair with your phone
  encrypt --text      Encrypt text (requires phone proximity)
  decrypt --text      Decrypt text (requires phone proximity)
  encrypt-file        Encrypt a file
  decrypt-file        Decrypt a file
  status             Check proximity / connection status
  server             (web mode only) Start the check-in server

Examples:
  python proximity_cli.py bluetooth pair
  python proximity_cli.py bluetooth encrypt --text "secret"
  python proximity_cli.py wifi pair
  python proximity_cli.py wifi encrypt --text "secret"
  python proximity_cli.py web server --port 7777
  python proximity_cli.py web encrypt --text "secret"
"""

import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

BANNER = """
╔══════════════════════════════════════════════════════════════╗
║          🔐  PROXIMITY-LOCKED AES-256 ENCRYPTION  🔐        ║
║                                                              ║
║   Your phone is the key. No phone nearby = no access.       ║
╚══════════════════════════════════════════════════════════════╝
"""


# ========================  BLUETOOTH MODE  =================================

def bluetooth_pair(args):
    from encryption.proximity_bluetooth import pair_device
    key, config = pair_device()
    print(f"\n   🔑 Your encryption key (save this!):")
    print(f"   {key.hex()}")


def bluetooth_encrypt(args):
    from encryption.proximity_bluetooth import bt_encrypt_text
    text = args.text or input("Enter text to encrypt: ")
    result = bt_encrypt_text(text)
    print(f"\n   🔒 Encrypted:\n   {result}")


def bluetooth_decrypt(args):
    from encryption.proximity_bluetooth import bt_decrypt_text
    text = args.text or input("Enter ciphertext: ")
    try:
        result = bt_decrypt_text(text)
        print(f"\n   🔓 Decrypted:\n   {result}")
    except Exception as e:
        print(f"\n   ❌ {e}", file=sys.stderr)
        sys.exit(1)


def bluetooth_encrypt_file(args):
    from encryption.proximity_bluetooth import bt_encrypt_file
    if not args.input or not args.output:
        print("Error: --input and --output required", file=sys.stderr)
        sys.exit(1)
    bt_encrypt_file(args.input, args.output)
    print(f"\n   🔒 File encrypted: {args.output}")


def bluetooth_decrypt_file(args):
    from encryption.proximity_bluetooth import bt_decrypt_file
    if not args.input or not args.output:
        print("Error: --input and --output required", file=sys.stderr)
        sys.exit(1)
    bt_decrypt_file(args.input, args.output)
    print(f"\n   🔓 File decrypted: {args.output}")


def bluetooth_status(args):
    from encryption.proximity_bluetooth import load_bt_config, check_device_nearby_sync
    config = load_bt_config()
    if not config:
        print("\n   ⚠️  No Bluetooth device paired.")
        print("   Run: python proximity_cli.py bluetooth pair")
        return
    print(f"\n   Paired device: {config['device_name']} ({config['device_address']})")
    print(f"   Paired at:     {config['paired_at']}")
    print(f"   Scanning...")
    nearby, rssi = check_device_nearby_sync(config['device_address'])
    if nearby:
        rssi_str = f"{rssi} dBm" if rssi else "N/A"
        print(f"   ✅ Phone detected (Signal: {rssi_str}) — Encryption UNLOCKED")
    else:
        print(f"   🚫 Phone NOT detected — Encryption LOCKED")


# ========================  WIFI MODE  ======================================

def wifi_pair(args):
    from encryption.proximity_wifi import pair_device
    key, config = pair_device()
    print(f"\n   🔑 Your encryption key (save this!):")
    print(f"   {key.hex()}")


def wifi_encrypt(args):
    from encryption.proximity_wifi import wifi_encrypt_text
    text = args.text or input("Enter text to encrypt: ")
    result = wifi_encrypt_text(text)
    print(f"\n   🔒 Encrypted:\n   {result}")


def wifi_decrypt(args):
    from encryption.proximity_wifi import wifi_decrypt_text
    text = args.text or input("Enter ciphertext: ")
    try:
        result = wifi_decrypt_text(text)
        print(f"\n   🔓 Decrypted:\n   {result}")
    except Exception as e:
        print(f"\n   ❌ {e}", file=sys.stderr)
        sys.exit(1)


def wifi_encrypt_file(args):
    from encryption.proximity_wifi import wifi_encrypt_file
    if not args.input or not args.output:
        print("Error: --input and --output required", file=sys.stderr)
        sys.exit(1)
    wifi_encrypt_file(args.input, args.output)
    print(f"\n   🔒 File encrypted: {args.output}")


def wifi_decrypt_file(args):
    from encryption.proximity_wifi import wifi_decrypt_file
    if not args.input or not args.output:
        print("Error: --input and --output required", file=sys.stderr)
        sys.exit(1)
    wifi_decrypt_file(args.input, args.output)
    print(f"\n   🔓 File decrypted: {args.output}")


def wifi_status(args):
    from encryption.proximity_wifi import load_wifi_config, is_phone_on_network
    config = load_wifi_config()
    if not config:
        print("\n   ⚠️  No WiFi device paired.")
        print("   Run: python proximity_cli.py wifi pair")
        return
    print(f"\n   Paired device: {config['device_name']}")
    print(f"   IP:  {config['device_ip']}")
    print(f"   MAC: {config['device_mac']}")
    print(f"   Paired at: {config['paired_at']}")
    print(f"   Checking network...")
    mac_check = config['device_mac'] if config['device_mac'] != 'UNKNOWN' else None
    nearby, detected_mac = is_phone_on_network(config['device_ip'], mac_check)
    if nearby:
        print(f"   ✅ Phone detected on network — Encryption UNLOCKED")
    else:
        print(f"   🚫 Phone NOT on network — Encryption LOCKED")


# ========================  WEB SERVER MODE  ================================

def web_server(args):
    from encryption.proximity_webserver import start_server
    port = args.port or 7777
    start_server(port=port, blocking=True)


def web_encrypt(args):
    from encryption.proximity_webserver import web_encrypt_text, is_phone_checked_in, start_server
    # Make sure server is running in background
    if not is_phone_checked_in():
        print("   ⚠️  Starting server in background...")
        start_server(port=args.port or 7777, blocking=False)
        print("   Waiting for phone check-in...")
        import time
        for i in range(60):
            if is_phone_checked_in():
                break
            time.sleep(1)
            if i % 5 == 0:
                print(f"   ⏳ Waiting... ({60-i}s remaining)")
        if not is_phone_checked_in():
            print("\n   ❌ Timeout: No phone checked in.", file=sys.stderr)
            sys.exit(1)

    text = args.text or input("Enter text to encrypt: ")
    result = web_encrypt_text(text)
    print(f"\n   🔒 Encrypted:\n   {result}")


def web_decrypt(args):
    from encryption.proximity_webserver import web_decrypt_text, is_phone_checked_in, start_server
    if not is_phone_checked_in():
        print("   ⚠️  Starting server in background...")
        start_server(port=args.port or 7777, blocking=False)
        print("   Waiting for phone check-in...")
        import time
        for i in range(60):
            if is_phone_checked_in():
                break
            time.sleep(1)
            if i % 5 == 0:
                print(f"   ⏳ Waiting... ({60-i}s remaining)")
        if not is_phone_checked_in():
            print("\n   ❌ Timeout: No phone checked in.", file=sys.stderr)
            sys.exit(1)

    text = args.text or input("Enter ciphertext: ")
    try:
        result = web_decrypt_text(text)
        print(f"\n   🔓 Decrypted:\n   {result}")
    except Exception as e:
        print(f"\n   ❌ {e}", file=sys.stderr)
        sys.exit(1)


def web_encrypt_file(args):
    from encryption.proximity_webserver import web_encrypt_file as _enc, is_phone_checked_in
    if not args.input or not args.output:
        print("Error: --input and --output required", file=sys.stderr)
        sys.exit(1)
    if not is_phone_checked_in():
        print("   ❌ No phone checked in. Start server first.", file=sys.stderr)
        sys.exit(1)
    _enc(args.input, args.output)
    print(f"\n   🔒 File encrypted: {args.output}")


def web_decrypt_file(args):
    from encryption.proximity_webserver import web_decrypt_file as _dec, is_phone_checked_in
    if not args.input or not args.output:
        print("Error: --input and --output required", file=sys.stderr)
        sys.exit(1)
    if not is_phone_checked_in():
        print("   ❌ No phone checked in. Start server first.", file=sys.stderr)
        sys.exit(1)
    _dec(args.input, args.output)
    print(f"\n   🔓 File decrypted: {args.output}")


def web_status(args):
    from encryption.proximity_webserver import is_phone_checked_in, load_web_config, _session_mgr
    config = load_web_config()
    if config:
        print(f"\n   Paired device: {config['device_fingerprint'][:20]}...")
        print(f"   Paired at:     {config['paired_at']}")
        print(f"   Server port:   {config['port']}")
    else:
        print("\n   ⚠️  No device paired yet.")
    if is_phone_checked_in():
        session = _session_mgr.get_active_session()
        print(f"   ✅ Phone CHECKED IN — Encryption UNLOCKED")
        if session:
            print(f"      Device: {session['device_fingerprint'][:16]}...")
            print(f"      From:   {session['remote_ip']}")
    else:
        print(f"   🚫 No phone checked in — Encryption LOCKED")


# ========================  MAIN  ===========================================

def main():
    print(BANNER)

    parser = argparse.ArgumentParser(
        description="Proximity-Locked AES-256 Encryption",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    subparsers = parser.add_subparsers(dest="mode", help="Proximity mode")

    # --- BLUETOOTH ---
    bt_parser = subparsers.add_parser("bluetooth", aliases=["bt"], help="Bluetooth proximity")
    bt_sub = bt_parser.add_subparsers(dest="command")
    bt_sub.add_parser("pair", help="Pair with your phone via Bluetooth")
    bt_enc = bt_sub.add_parser("encrypt", help="Encrypt text")
    bt_enc.add_argument("--text", "-t")
    bt_dec = bt_sub.add_parser("decrypt", help="Decrypt text")
    bt_dec.add_argument("--text", "-t")
    bt_ef = bt_sub.add_parser("encrypt-file", help="Encrypt a file")
    bt_ef.add_argument("--input", "-i")
    bt_ef.add_argument("--output", "-o")
    bt_df = bt_sub.add_parser("decrypt-file", help="Decrypt a file")
    bt_df.add_argument("--input", "-i")
    bt_df.add_argument("--output", "-o")
    bt_sub.add_parser("status", help="Check Bluetooth proximity")

    # --- WIFI ---
    wifi_parser = subparsers.add_parser("wifi", help="WiFi network proximity")
    wifi_sub = wifi_parser.add_subparsers(dest="command")
    wifi_sub.add_parser("pair", help="Pair with your phone on WiFi")
    wifi_enc = wifi_sub.add_parser("encrypt", help="Encrypt text")
    wifi_enc.add_argument("--text", "-t")
    wifi_dec = wifi_sub.add_parser("decrypt", help="Decrypt text")
    wifi_dec.add_argument("--text", "-t")
    wifi_ef = wifi_sub.add_parser("encrypt-file", help="Encrypt a file")
    wifi_ef.add_argument("--input", "-i")
    wifi_ef.add_argument("--output", "-o")
    wifi_df = wifi_sub.add_parser("decrypt-file", help="Decrypt a file")
    wifi_df.add_argument("--input", "-i")
    wifi_df.add_argument("--output", "-o")
    wifi_sub.add_parser("status", help="Check WiFi proximity")

    # --- WEB ---
    web_parser = subparsers.add_parser("web", help="Web server check-in proximity")
    web_sub = web_parser.add_subparsers(dest="command")
    web_srv = web_sub.add_parser("server", help="Start the check-in server")
    web_srv.add_argument("--port", "-p", type=int, default=7777)
    web_enc = web_sub.add_parser("encrypt", help="Encrypt text")
    web_enc.add_argument("--text", "-t")
    web_enc.add_argument("--port", "-p", type=int, default=7777)
    web_dec = web_sub.add_parser("decrypt", help="Decrypt text")
    web_dec.add_argument("--text", "-t")
    web_dec.add_argument("--port", "-p", type=int, default=7777)
    web_ef = web_sub.add_parser("encrypt-file", help="Encrypt a file")
    web_ef.add_argument("--input", "-i")
    web_ef.add_argument("--output", "-o")
    web_df = web_sub.add_parser("decrypt-file", help="Decrypt a file")
    web_df.add_argument("--input", "-i")
    web_df.add_argument("--output", "-o")
    web_sub.add_parser("status", help="Check web server status")

    args = parser.parse_args()

    if not args.mode:
        parser.print_help()
        print("\n   💡 Quick Start:")
        print("      python proximity_cli.py bluetooth pair")
        print("      python proximity_cli.py wifi pair")
        print("      python proximity_cli.py web server")
        sys.exit(0)

    # Dispatch
    mode = args.mode if args.mode != "bt" else "bluetooth"
    cmd = args.command

    if not cmd:
        print(f"   No command specified for '{mode}' mode.")
        print(f"   Try: python proximity_cli.py {mode} --help")
        sys.exit(0)

    dispatch = {
        ("bluetooth", "pair"): bluetooth_pair,
        ("bluetooth", "encrypt"): bluetooth_encrypt,
        ("bluetooth", "decrypt"): bluetooth_decrypt,
        ("bluetooth", "encrypt-file"): bluetooth_encrypt_file,
        ("bluetooth", "decrypt-file"): bluetooth_decrypt_file,
        ("bluetooth", "status"): bluetooth_status,
        ("wifi", "pair"): wifi_pair,
        ("wifi", "encrypt"): wifi_encrypt,
        ("wifi", "decrypt"): wifi_decrypt,
        ("wifi", "encrypt-file"): wifi_encrypt_file,
        ("wifi", "decrypt-file"): wifi_decrypt_file,
        ("wifi", "status"): wifi_status,
        ("web", "server"): web_server,
        ("web", "encrypt"): web_encrypt,
        ("web", "decrypt"): web_decrypt,
        ("web", "encrypt-file"): web_encrypt_file,
        ("web", "decrypt-file"): web_decrypt_file,
        ("web", "status"): web_status,
    }

    handler = dispatch.get((mode, cmd))
    if handler:
        handler(args)
    else:
        print(f"   Unknown command: {mode} {cmd}")
        sys.exit(1)


if __name__ == "__main__":
    main()