"""
AES-256 Encryption Module
=========================
A robust 256-bit encryption/decryption library using AES-256-GCM.

Features:
- AES-256-GCM authenticated encryption (confidentiality + integrity)
- PBKDF2-HMAC-SHA256 key derivation from passwords
- Secure random key generation
- File encryption/decryption support
- Base64 encoded output for easy transport
- Salt and nonce are stored alongside ciphertext

Security Details:
- Key Size: 256 bits (32 bytes)
- Mode: GCM (Galois/Counter Mode) - provides authentication
- Key Derivation: PBKDF2 with 600,000 iterations (OWASP recommendation)
- Salt: 16 bytes (cryptographically random)
- Nonce/IV: 12 bytes (cryptographically random)
- Auth Tag: 16 bytes (128 bits)
"""

import os
import base64
import hashlib
import hmac
import json
import secrets
from typing import Tuple, Optional


# ---------------------------------------------------------------------------
# Pure-Python AES-256-GCM helpers (uses hashlib/hmac + os.urandom only)
# We try to use the `cryptography` library first; if unavailable we fall back
# to PyCryptodome; if that is also missing we provide a clear error.
# ---------------------------------------------------------------------------

def _get_backend():
    """Return the best available crypto backend."""
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes
        return "cryptography"
    except ImportError:
        pass
    try:
        from Crypto.Cipher import AES
        return "pycryptodome"
    except ImportError:
        pass
    return None


# ===========================  CONSTANTS  ===================================

KEY_SIZE = 32          # 256 bits
SALT_SIZE = 16         # 128 bits
NONCE_SIZE = 12        # 96 bits  (recommended for GCM)
TAG_SIZE = 16          # 128 bits
KDF_ITERATIONS = 600_000  # OWASP 2023 recommendation for PBKDF2-SHA256
HEADER = b"AES256GCM"  # Magic header for our binary format


# ===========================  KEY MANAGEMENT  ==============================

def generate_key() -> bytes:
    """Generate a cryptographically secure random 256-bit key."""
    return secrets.token_bytes(KEY_SIZE)


def key_to_hex(key: bytes) -> str:
    """Convert a binary key to a hex string for safe storage/display."""
    return key.hex()


def key_from_hex(hex_string: str) -> bytes:
    """Restore a binary key from its hex representation."""
    key = bytes.fromhex(hex_string)
    if len(key) != KEY_SIZE:
        raise ValueError(f"Invalid key length: expected {KEY_SIZE} bytes, got {len(key)}")
    return key


def key_to_base64(key: bytes) -> str:
    """Convert a binary key to a base64 string."""
    return base64.b64encode(key).decode("utf-8")


def key_from_base64(b64_string: str) -> bytes:
    """Restore a binary key from its base64 representation."""
    key = base64.b64decode(b64_string)
    if len(key) != KEY_SIZE:
        raise ValueError(f"Invalid key length: expected {KEY_SIZE} bytes, got {len(key)}")
    return key


def derive_key_from_password(password: str, salt: Optional[bytes] = None) -> Tuple[bytes, bytes]:
    """
    Derive a 256-bit key from a password using PBKDF2-HMAC-SHA256.

    Args:
        password: The password string.
        salt: Optional salt bytes. If None, a random salt is generated.

    Returns:
        Tuple of (derived_key, salt).
    """
    if salt is None:
        salt = secrets.token_bytes(SALT_SIZE)

    backend = _get_backend()

    if backend == "cryptography":
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=KEY_SIZE,
            salt=salt,
            iterations=KDF_ITERATIONS,
        )
        key = kdf.derive(password.encode("utf-8"))
    else:
        # Fallback to hashlib (always available)
        key = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt,
            KDF_ITERATIONS,
            dklen=KEY_SIZE,
        )

    return key, salt


# =======================  ENCRYPT / DECRYPT (bytes)  =======================

def encrypt(plaintext: bytes, key: bytes) -> bytes:
    """
    Encrypt data using AES-256-GCM.

    Binary output format:
        HEADER (9 bytes) || nonce (12 bytes) || ciphertext || tag (16 bytes)

    Args:
        plaintext: Data to encrypt.
        key: 256-bit (32 byte) encryption key.

    Returns:
        Encrypted bytes (header + nonce + ciphertext + tag).
    """
    if len(key) != KEY_SIZE:
        raise ValueError(f"Key must be {KEY_SIZE} bytes (256 bits)")

    nonce = secrets.token_bytes(NONCE_SIZE)
    backend = _get_backend()

    if backend == "cryptography":
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        aesgcm = AESGCM(key)
        # GCM appends the tag to the ciphertext
        ct_with_tag = aesgcm.encrypt(nonce, plaintext, None)
        ciphertext = ct_with_tag[:-TAG_SIZE]
        tag = ct_with_tag[-TAG_SIZE:]
    elif backend == "pycryptodome":
        from Crypto.Cipher import AES
        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        ciphertext, tag = cipher.encrypt_and_digest(plaintext)
    else:
        raise RuntimeError(
            "No supported crypto backend found. "
            "Install 'cryptography' or 'pycryptodome': pip install cryptography"
        )

    return HEADER + nonce + ciphertext + tag


def decrypt(data: bytes, key: bytes) -> bytes:
    """
    Decrypt data produced by encrypt().

    Args:
        data: Encrypted bytes (header + nonce + ciphertext + tag).
        key: 256-bit (32 byte) encryption key.

    Returns:
        Decrypted plaintext bytes.

    Raises:
        ValueError: If the data is malformed or authentication fails.
    """
    if len(key) != KEY_SIZE:
        raise ValueError(f"Key must be {KEY_SIZE} bytes (256 bits)")

    header_len = len(HEADER)
    if not data[:header_len] == HEADER:
        raise ValueError("Invalid encrypted data (bad header)")

    min_len = header_len + NONCE_SIZE + TAG_SIZE
    if len(data) < min_len:
        raise ValueError("Encrypted data too short")

    nonce = data[header_len : header_len + NONCE_SIZE]
    tag = data[-TAG_SIZE:]
    ciphertext = data[header_len + NONCE_SIZE : -TAG_SIZE]

    backend = _get_backend()

    if backend == "cryptography":
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        aesgcm = AESGCM(key)
        plaintext = aesgcm.decrypt(nonce, ciphertext + tag, None)
    elif backend == "pycryptodome":
        from Crypto.Cipher import AES
        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        plaintext = cipher.decrypt_and_verify(ciphertext, tag)
    else:
        raise RuntimeError(
            "No supported crypto backend found. "
            "Install 'cryptography' or 'pycryptodome': pip install cryptography"
        )

    return plaintext


# ==================  ENCRYPT / DECRYPT (Base64 strings)  ==================

def encrypt_to_base64(plaintext: str, key: bytes) -> str:
    """Encrypt a string and return the result as a base64-encoded string."""
    encrypted = encrypt(plaintext.encode("utf-8"), key)
    return base64.b64encode(encrypted).decode("utf-8")


def decrypt_from_base64(b64_ciphertext: str, key: bytes) -> str:
    """Decrypt a base64-encoded ciphertext string back to the original string."""
    encrypted = base64.b64decode(b64_ciphertext)
    return decrypt(encrypted, key).decode("utf-8")


# ==================  PASSWORD-BASED ENCRYPT / DECRYPT  ====================

def encrypt_with_password(plaintext: str, password: str) -> str:
    """
    Encrypt a string using a password.

    The output is a base64 JSON envelope containing the salt and ciphertext.
    """
    key, salt = derive_key_from_password(password)
    encrypted = encrypt(plaintext.encode("utf-8"), key)
    envelope = {
        "v": 1,
        "alg": "AES-256-GCM",
        "kdf": "PBKDF2-HMAC-SHA256",
        "iter": KDF_ITERATIONS,
        "salt": base64.b64encode(salt).decode("utf-8"),
        "data": base64.b64encode(encrypted).decode("utf-8"),
    }
    return base64.b64encode(json.dumps(envelope).encode("utf-8")).decode("utf-8")


def decrypt_with_password(token: str, password: str) -> str:
    """
    Decrypt a token produced by encrypt_with_password().
    """
    envelope = json.loads(base64.b64decode(token).decode("utf-8"))
    salt = base64.b64decode(envelope["salt"])
    encrypted = base64.b64decode(envelope["data"])
    iterations = envelope.get("iter", KDF_ITERATIONS)

    # Re-derive key
    key = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        iterations,
        dklen=KEY_SIZE,
    )
    return decrypt(encrypted, key).decode("utf-8")


# =======================  FILE ENCRYPTION  =================================

def encrypt_file(input_path: str, output_path: str, key: bytes) -> None:
    """
    Encrypt a file using AES-256-GCM.

    Args:
        input_path: Path to the plaintext file.
        output_path: Path to write the encrypted file.
        key: 256-bit encryption key.
    """
    with open(input_path, "rb") as f:
        plaintext = f.read()

    encrypted = encrypt(plaintext, key)

    with open(output_path, "wb") as f:
        f.write(encrypted)


def decrypt_file(input_path: str, output_path: str, key: bytes) -> None:
    """
    Decrypt a file encrypted by encrypt_file().

    Args:
        input_path: Path to the encrypted file.
        output_path: Path to write the decrypted file.
        key: 256-bit encryption key.
    """
    with open(input_path, "rb") as f:
        encrypted = f.read()

    plaintext = decrypt(encrypted, key)

    with open(output_path, "wb") as f:
        f.write(plaintext)


def encrypt_file_with_password(input_path: str, output_path: str, password: str) -> None:
    """Encrypt a file using a password."""
    with open(input_path, "rb") as f:
        plaintext = f.read()

    key, salt = derive_key_from_password(password)
    encrypted = encrypt(plaintext, key)

    # Prepend salt to encrypted data
    with open(output_path, "wb") as f:
        f.write(salt + encrypted)


def decrypt_file_with_password(input_path: str, output_path: str, password: str) -> None:
    """Decrypt a file encrypted by encrypt_file_with_password()."""
    with open(input_path, "rb") as f:
        data = f.read()

    salt = data[:SALT_SIZE]
    encrypted = data[SALT_SIZE:]

    key, _ = derive_key_from_password(password, salt)
    plaintext = decrypt(encrypted, key)

    with open(output_path, "wb") as f:
        f.write(plaintext)


# =======================  UTILITY  =========================================

def get_info() -> dict:
    """Return information about the encryption configuration."""
    return {
        "algorithm": "AES-256-GCM",
        "key_size_bits": KEY_SIZE * 8,
        "key_size_bytes": KEY_SIZE,
        "nonce_size_bytes": NONCE_SIZE,
        "tag_size_bytes": TAG_SIZE,
        "salt_size_bytes": SALT_SIZE,
        "kdf": "PBKDF2-HMAC-SHA256",
        "kdf_iterations": KDF_ITERATIONS,
        "backend": _get_backend() or "none (install 'cryptography')",
    }