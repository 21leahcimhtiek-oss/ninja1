#!/usr/bin/env python3
"""
Local Web Server Proximity Key Module
========================================
Runs a local web server that your phone connects to.
As long as your phone is "checked in" (page open), encryption is unlocked.

Requirements:
    - Python 3.8+
    - No external packages (uses built-in http.server, threading)

How it works:
    1. SERVER START: A local HTTP server starts on your computer.
    2. PHONE CHECK-IN: Open the server URL on your phone's browser.
       Tap "Check In" — the phone sends a session token and begins heartbeats.
    3. HEARTBEAT: Every 5 seconds the phone pings the server. If heartbeats
       stop for >15 seconds, the session expires and encryption locks.
    4. ENCRYPTION GATE: encrypt/decrypt operations check for an active session.
       No active session → access denied.
    5. KEY SPLITTING: Same XOR-split approach — half the key is local,
       half is derived from the session's device fingerprint + secret salt.
"""

import hashlib
import http.server
import json
import os
import secrets
import socket
import sys
import threading
import time
from typing import Optional, Tuple, Dict
from urllib.parse import urlparse

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from encryption.aes256 import (
    encrypt_to_base64,
    decrypt_from_base64,
    encrypt_file,
    decrypt_file,
    KEY_SIZE,
    SALT_SIZE,
)

# ========================  CONSTANTS  ======================================

CONFIG_DIR = os.path.expanduser("~/.proximity_encrypt")
WEB_CONFIG_FILE = os.path.join(CONFIG_DIR, "webserver_config.json")
WEB_UI_DIR = os.path.join(os.path.dirname(__file__), "web_ui")
DEFAULT_PORT = 7777
HEARTBEAT_TIMEOUT = 15  # seconds — session expires if no heartbeat
SESSION_TOKEN_LENGTH = 64  # bytes


# ========================  SESSION MANAGER  ================================

class SessionManager:
    """Thread-safe session manager for phone check-ins."""

    def __init__(self):
        self._lock = threading.Lock()
        self._sessions: Dict[str, Dict] = {}  # token -> session info

    def create_session(self, device_fingerprint: str, user_agent: str, remote_ip: str) -> str:
        """Create a new session and return the session token."""
        token = secrets.token_hex(SESSION_TOKEN_LENGTH)
        with self._lock:
            # Invalidate any existing sessions from this device
            to_remove = [
                t for t, s in self._sessions.items()
                if s.get("device_fingerprint") == device_fingerprint
            ]
            for t in to_remove:
                del self._sessions[t]

            self._sessions[token] = {
                "device_fingerprint": device_fingerprint,
                "user_agent": user_agent,
                "remote_ip": remote_ip,
                "created_at": time.time(),
                "last_heartbeat": time.time(),
                "active": True,
            }
        return token

    def heartbeat(self, token: str) -> bool:
        """Update heartbeat for a session. Returns False if session not found."""
        with self._lock:
            session = self._sessions.get(token)
            if session and session["active"]:
                session["last_heartbeat"] = time.time()
                return True
        return False

    def remove_session(self, token: str):
        """Remove a session (check-out)."""
        with self._lock:
            if token in self._sessions:
                self._sessions[token]["active"] = False
                del self._sessions[token]

    def has_active_session(self) -> bool:
        """Check if there is at least one active, non-expired session."""
        with self._lock:
            now = time.time()
            # Clean expired sessions
            expired = [
                t for t, s in self._sessions.items()
                if now - s["last_heartbeat"] > HEARTBEAT_TIMEOUT
            ]
            for t in expired:
                del self._sessions[t]

            return any(s["active"] for s in self._sessions.values())

    def get_active_session(self) -> Optional[Dict]:
        """Get the first active session info (or None)."""
        with self._lock:
            now = time.time()
            for token, session in self._sessions.items():
                if session["active"] and now - session["last_heartbeat"] <= HEARTBEAT_TIMEOUT:
                    return {**session, "token": token}
        return None

    def get_active_fingerprint(self) -> Optional[str]:
        """Get the device fingerprint of the active session."""
        session = self.get_active_session()
        return session["device_fingerprint"] if session else None

    @property
    def session_count(self) -> int:
        with self._lock:
            return len(self._sessions)


# Global session manager
_session_mgr = SessionManager()


# ========================  KEY SPLITTING  ==================================

def derive_device_component(fingerprint: str, salt: bytes) -> bytes:
    """Derive a 256-bit key component from device fingerprint + salt."""
    return hashlib.pbkdf2_hmac(
        "sha256",
        fingerprint.encode("utf-8"),
        salt,
        iterations=200_000,
        dklen=KEY_SIZE,
    )


def split_key(full_key: bytes, fingerprint: str, salt: bytes) -> bytes:
    device_component = derive_device_component(fingerprint, salt)
    return bytes(a ^ b for a, b in zip(full_key, device_component))


def reconstruct_key(local_component: bytes, fingerprint: str, salt: bytes) -> bytes:
    device_component = derive_device_component(fingerprint, salt)
    return bytes(a ^ b for a, b in zip(local_component, device_component))


# ========================  CONFIG MANAGEMENT  ==============================

def _ensure_config_dir():
    os.makedirs(CONFIG_DIR, mode=0o700, exist_ok=True)


def save_web_config(device_fingerprint: str, local_component: bytes, salt: bytes, port: int):
    """Save web server pairing configuration."""
    _ensure_config_dir()
    config = {
        "version": 1,
        "type": "webserver",
        "device_fingerprint": device_fingerprint,
        "local_component_hex": local_component.hex(),
        "salt_hex": salt.hex(),
        "port": port,
        "paired_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    with open(WEB_CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)
    os.chmod(WEB_CONFIG_FILE, 0o600)
    return config


def load_web_config() -> Optional[Dict]:
    """Load web server pairing configuration."""
    if not os.path.exists(WEB_CONFIG_FILE):
        return None
    with open(WEB_CONFIG_FILE, "r") as f:
        return json.load(f)


# ========================  HTTP REQUEST HANDLER  ===========================

class ProximityHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP handler for the proximity check-in server."""

    def __init__(self, *args, **kwargs):
        # Serve files from the web_ui directory
        super().__init__(*args, directory=WEB_UI_DIR, **kwargs)

    def log_message(self, format, *args):
        """Custom log format."""
        msg = format % args
        if "/api/" in msg:
            print(f"   🌐 {self.address_string()} — {msg}")

    def do_POST(self):
        """Handle API POST requests."""
        path = urlparse(self.path).path
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length else b""

        try:
            data = json.loads(body) if body else {}
        except json.JSONDecodeError:
            data = {}

        if path == "/api/checkin":
            self._handle_checkin(data)
        elif path == "/api/checkout":
            self._handle_checkout(data)
        elif path == "/api/heartbeat":
            self._handle_heartbeat(data)
        elif path == "/api/status":
            self._handle_status()
        else:
            self._json_response(404, {"error": "Not found"})

    def do_GET(self):
        """Handle GET — serve static files + API status."""
        path = urlparse(self.path).path
        if path == "/api/status":
            self._handle_status()
        else:
            super().do_GET()

    def _handle_checkin(self, data):
        fingerprint = data.get("device_fingerprint", "UNKNOWN")
        user_agent = data.get("user_agent", self.headers.get("User-Agent", ""))
        remote_ip = self.client_address[0]

        token = _session_mgr.create_session(fingerprint, user_agent, remote_ip)

        # If this is the first check-in and no config exists, run initial pairing
        config = load_web_config()
        if config is None:
            # First-time pairing: generate a key
            full_key = secrets.token_bytes(KEY_SIZE)
            salt = secrets.token_bytes(SALT_SIZE)
            local_component = split_key(full_key, fingerprint, salt)
            port = self.server.server_address[1]
            save_web_config(fingerprint, local_component, salt, port)
            print(f"\n   ✅ PAIRED with device: {fingerprint}")
            print(f"   🔑 256-bit key generated and split")
            print(f"   💾 Config saved to: {WEB_CONFIG_FILE}")

        self._json_response(200, {
            "success": True,
            "session_token": token,
            "message": "Checked in successfully. Encryption unlocked.",
        })
        print(f"   📱 CHECK-IN: {fingerprint[:16]}... from {remote_ip}")

    def _handle_checkout(self, data):
        token = data.get("session_token")
        if token:
            _session_mgr.remove_session(token)
        self._json_response(200, {"success": True, "message": "Checked out."})
        print(f"   🚪 CHECK-OUT from {self.client_address[0]}")

    def _handle_heartbeat(self, data):
        token = data.get("session_token")
        if token and _session_mgr.heartbeat(token):
            self._json_response(200, {"success": True})
        else:
            self._json_response(200, {"success": False, "error": "Session expired"})

    def _handle_status(self):
        active = _session_mgr.has_active_session()
        session = _session_mgr.get_active_session()
        self._json_response(200, {
            "encryption_unlocked": active,
            "active_sessions": _session_mgr.session_count,
            "active_device": session["device_fingerprint"][:16] + "..." if session else None,
        })

    def _json_response(self, code, data):
        response = json.dumps(data).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(response)


# ========================  SERVER CONTROL  =================================

_server_instance = None
_server_thread = None


def get_local_ip() -> str:
    """Get this machine's LAN IP."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def start_server(port: int = DEFAULT_PORT, blocking: bool = True) -> str:
    """
    Start the proximity check-in web server.

    Args:
        port: Port to listen on.
        blocking: If True, blocks forever. If False, runs in a background thread.

    Returns:
        The URL to open on your phone.
    """
    global _server_instance, _server_thread

    local_ip = get_local_ip()
    url = f"http://{local_ip}:{port}"

    _server_instance = http.server.HTTPServer(("0.0.0.0", port), ProximityHandler)

    print("\n" + "=" * 60)
    print("   🔐 PROXIMITY ENCRYPTION SERVER")
    print("=" * 60)
    print(f"\n   Server running on port {port}")
    print(f"\n   📱 Open this URL on your phone:")
    print(f"   ➜  {url}")
    print(f"\n   (Your phone must be on the same WiFi network)")
    print(f"\n   Heartbeat timeout: {HEARTBEAT_TIMEOUT}s")
    print(f"   Encryption: LOCKED (waiting for phone check-in)")
    print("=" * 60 + "\n")

    if blocking:
        try:
            _server_instance.serve_forever()
        except KeyboardInterrupt:
            print("\n   Server stopped.")
            _server_instance.shutdown()
    else:
        _server_thread = threading.Thread(target=_server_instance.serve_forever, daemon=True)
        _server_thread.start()

    return url


def stop_server():
    """Stop the proximity server."""
    global _server_instance
    if _server_instance:
        _server_instance.shutdown()
        _server_instance = None
        print("   Server stopped.")


def is_phone_checked_in() -> bool:
    """Check if a phone is currently checked in."""
    return _session_mgr.has_active_session()


# ========================  PROXIMITY-GATED OPERATIONS  =====================

def _get_key_with_proximity_check() -> bytes:
    """Verify phone is checked in, then reconstruct the encryption key."""
    if not _session_mgr.has_active_session():
        raise RuntimeError(
            "🚫 ACCESS DENIED — No phone is checked in.\n"
            "   Open the server URL on your phone and tap 'Check In'."
        )

    config = load_web_config()
    if not config:
        raise RuntimeError(
            "No device paired yet. Start the server and check in from your phone first."
        )

    fingerprint = _session_mgr.get_active_fingerprint()
    if not fingerprint:
        raise RuntimeError("🚫 Session lost. Please check in again from your phone.")

    local_component = bytes.fromhex(config["local_component_hex"])
    salt = bytes.fromhex(config["salt_hex"])

    # Use the PAIRED fingerprint (not the current session's) for key reconstruction
    paired_fingerprint = config["device_fingerprint"]

    # Verify it's the same device
    if fingerprint != paired_fingerprint:
        raise RuntimeError(
            f"🚫 ACCESS DENIED — Checked-in device doesn't match paired device.\n"
            f"   Paired: {paired_fingerprint[:16]}...\n"
            f"   Current: {fingerprint[:16]}..."
        )

    return reconstruct_key(local_component, paired_fingerprint, salt)


def web_encrypt_text(plaintext: str) -> str:
    """Encrypt text — requires phone check-in."""
    key = _get_key_with_proximity_check()
    return encrypt_to_base64(plaintext, key)


def web_decrypt_text(ciphertext: str) -> str:
    """Decrypt text — requires phone check-in."""
    key = _get_key_with_proximity_check()
    return decrypt_from_base64(ciphertext, key)


def web_encrypt_file(input_path: str, output_path: str) -> None:
    """Encrypt file — requires phone check-in."""
    key = _get_key_with_proximity_check()
    encrypt_file(input_path, output_path, key)


def web_decrypt_file(input_path: str, output_path: str) -> None:
    """Decrypt file — requires phone check-in."""
    key = _get_key_with_proximity_check()
    decrypt_file(input_path, output_path, key)


# ========================  STANDALONE  =====================================

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Proximity Encryption Web Server")
    parser.add_argument("--port", "-p", type=int, default=DEFAULT_PORT, help="Port (default: 7777)")
    args = parser.parse_args()
    start_server(port=args.port, blocking=True)