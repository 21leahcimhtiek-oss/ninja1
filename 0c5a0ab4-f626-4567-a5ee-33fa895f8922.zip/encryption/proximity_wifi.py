#!/usr/bin/env python3
"""
WiFi Network Proximity Key Module
====================================
Uses your phone's presence on the local WiFi network as a proximity key.
Encryption/decryption is only allowed when your phone is detected on the same network.

Requirements (on your local machine):
    - Python 3.8+
    - No external packages needed (uses built-in socket, subprocess)
    - Works on Windows, macOS, and Linux

How it works:
    1. PAIRING: You enter your phone's local IP address (or it's discovered via
       network scan). The phone's MAC address and IP are stored.
    2. PROXIMITY CHECK: Before encrypt/decrypt, the system pings your phone
       and/or checks the ARP table for its MAC address on the local network.
    3. KEY SPLITTING: Same XOR-split approach as Bluetooth —
       half the key is local, half is derived from your phone's MAC address.
"""

import hashlib
import json
import os
import platform
import re
import secrets
import socket
import subprocess
import sys
import time
from typing import Optional, Tuple, List, Dict

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from encryption.aes256 import (
    encrypt,
    decrypt,
    encrypt_to_base64,
    decrypt_from_base64,
    encrypt_file,
    decrypt_file,
    KEY_SIZE,
    SALT_SIZE,
)

# ========================  CONSTANTS  ======================================

CONFIG_DIR = os.path.expanduser("~/.proximity_encrypt")
WIFI_CONFIG_FILE = os.path.join(CONFIG_DIR, "wifi_config.json")
PING_TIMEOUT = 2  # seconds
SCAN_TIMEOUT = 5  # seconds per host


# ========================  NETWORK UTILITIES  ==============================

def get_local_ip() -> str:
    """Get this machine's local IP address."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def get_subnet() -> str:
    """Get the local subnet (e.g., '192.168.1')."""
    ip = get_local_ip()
    parts = ip.split(".")
    return ".".join(parts[:3])


def ping_host(ip: str, timeout: int = PING_TIMEOUT) -> bool:
    """Ping a host to check if it's reachable."""
    system = platform.system().lower()
    if system == "windows":
        cmd = ["ping", "-n", "1", "-w", str(timeout * 1000), ip]
    else:
        cmd = ["ping", "-c", "1", "-W", str(timeout), ip]

    try:
        result = subprocess.run(
            cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=timeout + 2
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def get_mac_from_arp(ip: str) -> Optional[str]:
    """Look up a MAC address from the ARP table for a given IP."""
    system = platform.system().lower()

    try:
        if system == "windows":
            result = subprocess.run(["arp", "-a", ip], capture_output=True, text=True, timeout=5)
        else:
            result = subprocess.run(["arp", "-n", ip], capture_output=True, text=True, timeout=5)

        output = result.stdout

        # Match MAC address patterns (xx:xx:xx:xx:xx:xx or xx-xx-xx-xx-xx-xx)
        mac_pattern = r"([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}"
        match = re.search(mac_pattern, output)
        if match:
            return match.group(0).upper().replace("-", ":")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return None


def scan_network(subnet: str = None, timeout: int = SCAN_TIMEOUT) -> List[Dict]:
    """
    Scan the local network for active devices.

    Returns:
        List of dicts with 'ip', 'mac', 'hostname' keys.
    """
    if subnet is None:
        subnet = get_subnet()

    print(f"   🔍 Scanning network {subnet}.0/24 ...")
    devices = []

    # First, try using 'arp-scan' if available (Linux, fast)
    try:
        result = subprocess.run(
            ["sudo", "arp-scan", "--localnet", "--timeout=1000"],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                match = re.match(
                    r"(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F:]+)\s*(.*)",
                    line
                )
                if match:
                    devices.append({
                        "ip": match.group(1),
                        "mac": match.group(2).upper(),
                        "hostname": match.group(3).strip() or "Unknown",
                    })
            if devices:
                return devices
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    # Fallback: ping sweep + ARP lookup
    print(f"   Using ping sweep (this may take a moment)...")
    import concurrent.futures

    def check_host(i):
        ip = f"{subnet}.{i}"
        if ping_host(ip, timeout=1):
            mac = get_mac_from_arp(ip)
            try:
                hostname = socket.gethostbyaddr(ip)[0]
            except socket.herror:
                hostname = "Unknown"
            return {"ip": ip, "mac": mac or "Unknown", "hostname": hostname}
        return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
        futures = {executor.submit(check_host, i): i for i in range(1, 255)}
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result:
                devices.append(result)

    devices.sort(key=lambda d: [int(x) for x in d["ip"].split(".")])
    return devices


def is_phone_on_network(ip: str, mac: str = None) -> Tuple[bool, Optional[str]]:
    """
    Check if a phone is on the local network.

    Args:
        ip: The phone's expected IP address.
        mac: The phone's expected MAC address (optional, for extra verification).

    Returns:
        Tuple of (is_present: bool, detected_mac: Optional[str])
    """
    print(f"   📡 Checking for device at {ip}...")

    # Ping the device
    if not ping_host(ip):
        # IP might have changed — cannot confirm presence
        return False, None

    # Get current MAC from ARP
    current_mac = get_mac_from_arp(ip)

    if mac and current_mac:
        # Verify MAC matches (prevents IP spoofing)
        if current_mac.upper() == mac.upper():
            return True, current_mac
        else:
            print(f"   ⚠️  IP {ip} responded but MAC doesn't match!")
            print(f"      Expected: {mac}, Got: {current_mac}")
            return False, current_mac

    # If no MAC to verify, just trust the ping
    return True, current_mac


# ========================  KEY SPLITTING  ==================================

def derive_device_component(mac_address: str, salt: bytes) -> bytes:
    """Derive a 256-bit key component from a MAC address + salt."""
    normalized_mac = mac_address.upper().replace("-", ":").strip()
    return hashlib.pbkdf2_hmac(
        "sha256",
        normalized_mac.encode("utf-8"),
        salt,
        iterations=200_000,
        dklen=KEY_SIZE,
    )


def split_key(full_key: bytes, mac_address: str, salt: bytes) -> bytes:
    """Split a key using XOR with the device component."""
    device_component = derive_device_component(mac_address, salt)
    return bytes(a ^ b for a, b in zip(full_key, device_component))


def reconstruct_key(local_component: bytes, mac_address: str, salt: bytes) -> bytes:
    """Reconstruct the full key from local component and device identity."""
    device_component = derive_device_component(mac_address, salt)
    return bytes(a ^ b for a, b in zip(local_component, device_component))


# ========================  CONFIG MANAGEMENT  ==============================

def _ensure_config_dir():
    os.makedirs(CONFIG_DIR, mode=0o700, exist_ok=True)


def save_wifi_config(ip: str, mac: str, device_name: str, local_component: bytes, salt: bytes):
    """Save WiFi pairing configuration."""
    _ensure_config_dir()
    config = {
        "version": 1,
        "type": "wifi",
        "device_ip": ip,
        "device_mac": mac.upper(),
        "device_name": device_name,
        "local_component_hex": local_component.hex(),
        "salt_hex": salt.hex(),
        "paired_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    with open(WIFI_CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)
    os.chmod(WIFI_CONFIG_FILE, 0o600)
    return config


def load_wifi_config() -> Optional[Dict]:
    """Load WiFi pairing configuration."""
    if not os.path.exists(WIFI_CONFIG_FILE):
        return None
    with open(WIFI_CONFIG_FILE, "r") as f:
        return json.load(f)


# ========================  PAIRING  ========================================

def pair_device(ip: str = None, mac: str = None, device_name: str = "Phone") -> Tuple[bytes, Dict]:
    """
    Pair with a device on the local network.

    Returns:
        Tuple of (full_encryption_key, config_dict)
    """
    print("\n   📱 WiFi Proximity Key — Device Pairing")
    print("   " + "=" * 50)
    print(f"   Your IP: {get_local_ip()}")

    if ip is None:
        # Interactive: scan or manual entry
        print("\n   Options:")
        print("   [1] Scan network for devices")
        print("   [2] Enter phone IP manually")

        choice = input("\n   Choose (1/2): ").strip()

        if choice == "1":
            devices = scan_network()
            if not devices:
                raise RuntimeError("No devices found on the network.")

            print(f"\n   Found {len(devices)} device(s):\n")
            for i, d in enumerate(devices):
                print(f"   [{i+1}] {d['ip']:.<18} MAC: {d['mac']:.<20} {d['hostname']}")

            while True:
                try:
                    sel = int(input(f"\n   Select your phone (1-{len(devices)}): "))
                    if 1 <= sel <= len(devices):
                        selected = devices[sel - 1]
                        ip = selected["ip"]
                        mac = selected["mac"]
                        device_name = selected["hostname"]
                        break
                except (ValueError, IndexError):
                    pass
                print("   Invalid. Try again.")
        else:
            ip = input("   Enter phone IP address: ").strip()
            print(f"   Pinging {ip}...")
            if not ping_host(ip):
                raise RuntimeError(f"Cannot reach {ip}. Make sure your phone is on the same WiFi.")
            mac = get_mac_from_arp(ip) or "UNKNOWN"
            device_name = input("   Device name (e.g., 'My iPhone'): ").strip() or "Phone"

    if mac is None or mac == "UNKNOWN":
        # Try to discover MAC
        ping_host(ip)
        mac = get_mac_from_arp(ip) or "UNKNOWN"

    if mac == "UNKNOWN":
        print("   ⚠️  Could not determine MAC address. Using IP-only verification.")
        print("      (Less secure: IP addresses can change)")

    # Generate encryption key and split it
    full_key = secrets.token_bytes(KEY_SIZE)
    salt = secrets.token_bytes(SALT_SIZE)

    if mac != "UNKNOWN":
        local_component = split_key(full_key, mac, salt)
    else:
        # Fallback: use IP for derivation (less secure)
        local_component = split_key(full_key, ip, salt)

    config = save_wifi_config(ip, mac, device_name, local_component, salt)

    print(f"\n   ✅ Paired with: {device_name}")
    print(f"      IP:  {ip}")
    print(f"      MAC: {mac}")
    print(f"   🔑 256-bit encryption key generated and split")
    print(f"   💾 Config saved to: {WIFI_CONFIG_FILE}")

    return full_key, config


# ========================  PROXIMITY-GATED OPERATIONS  =====================

def _get_key_with_proximity_check() -> bytes:
    """Load config, verify phone on network, reconstruct key."""
    config = load_wifi_config()
    if not config:
        raise RuntimeError(
            "No WiFi device paired. Run pairing first:\n"
            "  python proximity_cli.py wifi pair"
        )

    ip = config["device_ip"]
    mac = config["device_mac"]
    device_name = config["device_name"]
    local_component = bytes.fromhex(config["local_component_hex"])
    salt = bytes.fromhex(config["salt_hex"])

    print(f"\n   📱 Looking for: {device_name} ({ip})")
    nearby, detected_mac = is_phone_on_network(ip, mac if mac != "UNKNOWN" else None)

    if not nearby:
        raise RuntimeError(
            f"🚫 ACCESS DENIED — '{device_name}' not found on the network.\n"
            "   Make sure your phone is connected to the same WiFi."
        )

    print(f"   ✅ Phone detected on network!")

    identity = mac if mac != "UNKNOWN" else ip
    return reconstruct_key(local_component, identity, salt)


def wifi_encrypt_text(plaintext: str) -> str:
    """Encrypt text — requires phone on same WiFi."""
    key = _get_key_with_proximity_check()
    return encrypt_to_base64(plaintext, key)


def wifi_decrypt_text(ciphertext: str) -> str:
    """Decrypt text — requires phone on same WiFi."""
    key = _get_key_with_proximity_check()
    return decrypt_from_base64(ciphertext, key)


def wifi_encrypt_file(input_path: str, output_path: str) -> None:
    """Encrypt file — requires phone on same WiFi."""
    key = _get_key_with_proximity_check()
    encrypt_file(input_path, output_path, key)


def wifi_decrypt_file(input_path: str, output_path: str) -> None:
    """Decrypt file — requires phone on same WiFi."""
    key = _get_key_with_proximity_check()
    decrypt_file(input_path, output_path, key)