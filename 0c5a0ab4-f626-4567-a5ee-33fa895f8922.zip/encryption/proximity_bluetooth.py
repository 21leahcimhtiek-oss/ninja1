#!/usr/bin/env python3
"""
Bluetooth Proximity Key Module
================================
Uses your phone's Bluetooth signal as a proximity key.
Encryption/decryption is only allowed when your phone is detected nearby.

Requirements (on your local machine):
    pip install bleak

How it works:
    1. PAIRING: Scan for nearby Bluetooth devices, select your phone,
       and store its address + a device-derived key component.
    2. PROXIMITY CHECK: Before encrypt/decrypt, the system scans for
       your phone's Bluetooth address. If found → access granted.
    3. KEY SPLITTING: The 256-bit key is split into two halves:
       - Local half: stored in a config file on disk
       - Device half: derived from your phone's unique BT address + a secret salt
       Both halves are XOR-combined to reconstruct the full key.
       Without your phone nearby, the key cannot be verified/reconstructed.
"""

import asyncio
import hashlib
import json
import os
import secrets
import sys
import time
from typing import Optional, Tuple, List, Dict

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from encryption.aes256 import (
    encrypt,
    decrypt,
    encrypt_to_base64,
    decrypt_from_base64,
    encrypt_file,
    decrypt_file,
    KEY_SIZE,
    SALT_SIZE,
)

# ========================  CONSTANTS  ======================================

CONFIG_DIR = os.path.expanduser("~/.proximity_encrypt")
BT_CONFIG_FILE = os.path.join(CONFIG_DIR, "bluetooth_config.json")
SCAN_TIMEOUT = 10  # seconds to scan for BT devices
PROXIMITY_RSSI_THRESHOLD = -75  # dBm — closer = higher value


# ========================  BLUETOOTH SCANNER  ==============================

async def scan_bluetooth_devices(timeout: int = SCAN_TIMEOUT) -> List[Dict]:
    """
    Scan for nearby Bluetooth (BLE) devices.

    Returns:
        List of dicts with 'address', 'name', 'rssi' keys.
    """
    try:
        from bleak import BleakScanner
    except ImportError:
        raise ImportError(
            "Bluetooth scanning requires 'bleak'. Install it with:\n"
            "  pip install bleak"
        )

    print(f"   🔍 Scanning for Bluetooth devices ({timeout}s)...")
    devices = await BleakScanner.discover(timeout=timeout, return_adv=True)

    results = []
    for address, (device, adv_data) in devices.items():
        results.append({
            "address": address,
            "name": device.name or "Unknown",
            "rssi": adv_data.rssi if adv_data else None,
        })

    # Sort by signal strength (closest first)
    results.sort(key=lambda d: d.get("rssi") or -999, reverse=True)
    return results


async def is_device_nearby(target_address: str, timeout: int = SCAN_TIMEOUT) -> Tuple[bool, Optional[int]]:
    """
    Check if a specific Bluetooth device is nearby.

    Args:
        target_address: The BT MAC address to look for.
        timeout: Scan duration in seconds.

    Returns:
        Tuple of (is_nearby: bool, rssi: Optional[int])
    """
    try:
        from bleak import BleakScanner
    except ImportError:
        raise ImportError("Bluetooth requires 'bleak': pip install bleak")

    print(f"   📡 Scanning for device {target_address}...")
    devices = await BleakScanner.discover(timeout=timeout, return_adv=True)

    target = target_address.upper()
    for address, (device, adv_data) in devices.items():
        if address.upper() == target:
            rssi = adv_data.rssi if adv_data else None
            return True, rssi

    return False, None


def scan_devices_sync(timeout: int = SCAN_TIMEOUT) -> List[Dict]:
    """Synchronous wrapper for scan_bluetooth_devices."""
    return asyncio.run(scan_bluetooth_devices(timeout))


def check_device_nearby_sync(address: str, timeout: int = SCAN_TIMEOUT) -> Tuple[bool, Optional[int]]:
    """Synchronous wrapper for is_device_nearby."""
    return asyncio.run(is_device_nearby(address, timeout))


# ========================  KEY SPLITTING  ==================================

def derive_device_component(bt_address: str, salt: bytes) -> bytes:
    """
    Derive a 256-bit key component from a Bluetooth address + salt.
    This acts as the 'device half' of the split key.
    """
    return hashlib.pbkdf2_hmac(
        "sha256",
        bt_address.upper().encode("utf-8"),
        salt,
        iterations=200_000,
        dklen=KEY_SIZE,
    )


def split_key(full_key: bytes, bt_address: str, salt: bytes) -> bytes:
    """
    Split a key: XOR the full key with the device component to get the local component.

    full_key = local_component XOR device_component
    → local_component = full_key XOR device_component
    """
    device_component = derive_device_component(bt_address, salt)
    local_component = bytes(a ^ b for a, b in zip(full_key, device_component))
    return local_component


def reconstruct_key(local_component: bytes, bt_address: str, salt: bytes) -> bytes:
    """
    Reconstruct the full key from the local component and device identity.

    full_key = local_component XOR device_component
    """
    device_component = derive_device_component(bt_address, salt)
    full_key = bytes(a ^ b for a, b in zip(local_component, device_component))
    return full_key


# ========================  CONFIG MANAGEMENT  ==============================

def _ensure_config_dir():
    os.makedirs(CONFIG_DIR, mode=0o700, exist_ok=True)


def save_bt_config(bt_address: str, device_name: str, local_component: bytes, salt: bytes):
    """Save Bluetooth pairing configuration."""
    _ensure_config_dir()
    config = {
        "version": 1,
        "type": "bluetooth",
        "device_address": bt_address.upper(),
        "device_name": device_name,
        "local_component_hex": local_component.hex(),
        "salt_hex": salt.hex(),
        "paired_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    with open(BT_CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)
    os.chmod(BT_CONFIG_FILE, 0o600)
    return config


def load_bt_config() -> Optional[Dict]:
    """Load Bluetooth pairing configuration."""
    if not os.path.exists(BT_CONFIG_FILE):
        return None
    with open(BT_CONFIG_FILE, "r") as f:
        return json.load(f)


# ========================  PAIRING  ========================================

def pair_device(bt_address: str = None, device_name: str = "Phone") -> Tuple[bytes, Dict]:
    """
    Pair with a Bluetooth device and generate a proximity-locked encryption key.

    If bt_address is None, scans for devices and prompts user to select one.

    Returns:
        Tuple of (full_encryption_key, config_dict)
    """
    if bt_address is None:
        # Interactive pairing
        print("\n   📱 Bluetooth Proximity Key — Device Pairing")
        print("   " + "=" * 50)
        devices = scan_devices_sync()

        if not devices:
            raise RuntimeError("No Bluetooth devices found. Make sure your phone's Bluetooth is on.")

        print(f"\n   Found {len(devices)} device(s):\n")
        for i, d in enumerate(devices):
            rssi_str = f"{d['rssi']} dBm" if d['rssi'] else "N/A"
            print(f"   [{i+1}] {d['name']:.<30} {d['address']}  (RSSI: {rssi_str})")

        while True:
            try:
                choice = int(input(f"\n   Select your phone (1-{len(devices)}): "))
                if 1 <= choice <= len(devices):
                    selected = devices[choice - 1]
                    bt_address = selected["address"]
                    device_name = selected["name"]
                    break
            except (ValueError, IndexError):
                pass
            print("   Invalid selection. Try again.")
    else:
        bt_address = bt_address.upper()

    # Generate encryption key and split it
    full_key = secrets.token_bytes(KEY_SIZE)
    salt = secrets.token_bytes(SALT_SIZE)
    local_component = split_key(full_key, bt_address, salt)

    # Save config
    config = save_bt_config(bt_address, device_name, local_component, salt)

    print(f"\n   ✅ Paired with: {device_name} ({bt_address})")
    print(f"   🔑 256-bit encryption key generated and split")
    print(f"   💾 Config saved to: {BT_CONFIG_FILE}")

    return full_key, config


# ========================  PROXIMITY-GATED OPERATIONS  =====================

def _get_key_with_proximity_check() -> bytes:
    """
    Internal: Load config, verify phone proximity, reconstruct key.
    Raises RuntimeError if phone is not nearby.
    """
    config = load_bt_config()
    if not config:
        raise RuntimeError(
            "No Bluetooth device paired. Run pairing first:\n"
            "  python proximity_cli.py bluetooth pair"
        )

    bt_address = config["device_address"]
    device_name = config["device_name"]
    local_component = bytes.fromhex(config["local_component_hex"])
    salt = bytes.fromhex(config["salt_hex"])

    print(f"\n   📱 Looking for: {device_name} ({bt_address})")
    nearby, rssi = check_device_nearby_sync(bt_address)

    if not nearby:
        raise RuntimeError(
            f"🚫 ACCESS DENIED — Phone '{device_name}' not detected nearby.\n"
            "   Make sure your phone's Bluetooth is on and in range."
        )

    rssi_str = f"{rssi} dBm" if rssi else "unknown"
    print(f"   ✅ Phone detected! (Signal: {rssi_str})")

    # Optional: enforce minimum signal strength
    if rssi is not None and rssi < PROXIMITY_RSSI_THRESHOLD:
        raise RuntimeError(
            f"🚫 Phone detected but too far away (RSSI: {rssi} dBm).\n"
            f"   Move closer (threshold: {PROXIMITY_RSSI_THRESHOLD} dBm)."
        )

    return reconstruct_key(local_component, bt_address, salt)


def bt_encrypt_text(plaintext: str) -> str:
    """Encrypt text — requires phone proximity."""
    key = _get_key_with_proximity_check()
    return encrypt_to_base64(plaintext, key)


def bt_decrypt_text(ciphertext: str) -> str:
    """Decrypt text — requires phone proximity."""
    key = _get_key_with_proximity_check()
    return decrypt_from_base64(ciphertext, key)


def bt_encrypt_file(input_path: str, output_path: str) -> None:
    """Encrypt a file — requires phone proximity."""
    key = _get_key_with_proximity_check()
    encrypt_file(input_path, output_path, key)


def bt_decrypt_file(input_path: str, output_path: str) -> None:
    """Decrypt a file — requires phone proximity."""
    key = _get_key_with_proximity_check()
    decrypt_file(input_path, output_path, key)